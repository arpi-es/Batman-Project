package b4a.example.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_main{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
views.get("pnlheader").vw.setLeft((int)(0d));
views.get("pnlheader").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlheader").vw.setTop((int)(0d));
views.get("pnlheader").vw.setHeight((int)((10d / 100 * height) - (0d)));
views.get("lblheader").vw.setLeft((int)(0d));
views.get("lblheader").vw.setWidth((int)((100d / 100 * width) - (0d)));
//BA.debugLineNum = 6;BA.debugLine="lblHeader.Height = pnlHeader.Height"[main/General script]
views.get("lblheader").vw.setHeight((int)((views.get("pnlheader").vw.getHeight())));
//BA.debugLineNum = 9;BA.debugLine="pnlSep.SetLeftAndRight( 0, 100%x)"[main/General script]
views.get("pnlsep").vw.setLeft((int)(0d));
views.get("pnlsep").vw.setWidth((int)((100d / 100 * width) - (0d)));
//BA.debugLineNum = 10;BA.debugLine="pnlSep.Top = pnlHeader.Bottom -1"[main/General script]
views.get("pnlsep").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())-1d));
//BA.debugLineNum = 11;BA.debugLine="pnlSep.Height = 1"[main/General script]
views.get("pnlsep").vw.setHeight((int)(1d));
//BA.debugLineNum = 15;BA.debugLine="pnlHolder.SetLeftAndRight( 0, 100%x)"[main/General script]
views.get("pnlholder").vw.setLeft((int)(0d));
views.get("pnlholder").vw.setWidth((int)((100d / 100 * width) - (0d)));
//BA.debugLineNum = 16;BA.debugLine="pnlHolder.SetTopAndBottom(10%y, 100%y)"[main/General script]
views.get("pnlholder").vw.setTop((int)((10d / 100 * height)));
views.get("pnlholder").vw.setHeight((int)((100d / 100 * height) - ((10d / 100 * height))));
//BA.debugLineNum = 20;BA.debugLine="clvMovies.SetLeftAndRight(15, 100%x - 15)"[main/General script]
views.get("clvmovies").vw.setLeft((int)(15d));
views.get("clvmovies").vw.setWidth((int)((100d / 100 * width)-15d - (15d)));
//BA.debugLineNum = 21;BA.debugLine="clvMovies.SetTopAndBottom(0, 90%y)"[main/General script]
views.get("clvmovies").vw.setTop((int)(0d));
views.get("clvmovies").vw.setHeight((int)((90d / 100 * height) - (0d)));

}
}