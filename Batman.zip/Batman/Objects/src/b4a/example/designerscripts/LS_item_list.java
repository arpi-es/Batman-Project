package b4a.example.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_item_list{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _inth="";
//BA.debugLineNum = 2;BA.debugLine="inth = pnlItem.Height"[item_list/General script]
_inth = (BA.NumberToString(views.get("pnlitem").vw.getHeight()));
//BA.debugLineNum = 4;BA.debugLine="lblTitle.SetTopAndBottom(0 , inth/3)"[item_list/General script]
views.get("lbltitle").vw.setTop((int)(0d));
views.get("lbltitle").vw.setHeight((int)(Double.parseDouble(_inth)/3d - (0d)));
//BA.debugLineNum = 5;BA.debugLine="lblYear.SetTopAndBottom(inth/3 , 2*inth/3)"[item_list/General script]
views.get("lblyear").vw.setTop((int)(Double.parseDouble(_inth)/3d));
views.get("lblyear").vw.setHeight((int)(2d*Double.parseDouble(_inth)/3d - (Double.parseDouble(_inth)/3d)));
//BA.debugLineNum = 6;BA.debugLine="lblType.SetTopAndBottom(2*inth/3 , inth)"[item_list/General script]
views.get("lbltype").vw.setTop((int)(2d*Double.parseDouble(_inth)/3d));
views.get("lbltype").vw.setHeight((int)(Double.parseDouble(_inth) - (2d*Double.parseDouble(_inth)/3d)));

}
}