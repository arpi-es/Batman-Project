package b4a.example.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_page_detail{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
views.get("pnlheader").vw.setLeft((int)(0d));
views.get("pnlheader").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlheader").vw.setTop((int)(0d));
views.get("pnlheader").vw.setHeight((int)((10d / 100 * height) - (0d)));
views.get("lblheader").vw.setLeft((int)(0d));
views.get("lblheader").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("lblheader").vw.setHeight((int)((views.get("pnlheader").vw.getHeight())));
views.get("pnlsep").vw.setLeft((int)(0d));
views.get("pnlsep").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlsep").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())-1d));
views.get("pnlsep").vw.setHeight((int)(1d));
views.get("pnlholder").vw.setLeft((int)(0d));
views.get("pnlholder").vw.setWidth((int)((100d / 100 * width) - (0d)));
views.get("pnlholder").vw.setTop((int)((10d / 100 * height)));
views.get("pnlholder").vw.setHeight((int)((100d / 100 * height) - ((10d / 100 * height))));
views.get("pnlinfo").vw.setLeft((int)(15d));
views.get("pnlinfo").vw.setWidth((int)((100d / 100 * width)-15d - (15d)));
//BA.debugLineNum = 19;BA.debugLine="pnlInfo.SetTopAndBottom(15, 90%y-15)"[page_detail/General script]
views.get("pnlinfo").vw.setTop((int)(15d));
views.get("pnlinfo").vw.setHeight((int)((90d / 100 * height)-15d - (15d)));

}
}