package b4a.example;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "b4a.example", "b4a.example.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "b4a.example", "b4a.example.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.example.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            main mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.sql.SQL _sql1 = null;
public static anywheresoftware.b4a.keywords.constants.TypefaceWrapper _tfontawesome = null;
public com.glide.Hitex_Glide _glide = null;
public anywheresoftware.b4a.objects.StringUtils _su = null;
public b4a.example3.customlistview _clvmovies = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.moviedetailactivity _moviedetailactivity = null;
public b4a.example.starter _starter = null;
public b4a.example.cpublic _cpublic = null;
public b4a.example.servicedatadownloader _servicedatadownloader = null;
public b4a.example.httputils2service _httputils2service = null;

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
vis = vis | (moviedetailactivity.mostCurrent != null);
return vis;}
public static String  _activity_create(boolean _firsttime) throws Exception{
 //BA.debugLineNum = 35;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
 //BA.debugLineNum = 37;BA.debugLine="Activity.LoadLayout(\"main\")";
mostCurrent._activity.LoadLayout("main",mostCurrent.activityBA);
 //BA.debugLineNum = 41;BA.debugLine="If FirstTime Then";
if (_firsttime) { 
 //BA.debugLineNum = 42;BA.debugLine="CopyDB(cPublic.DBFileName)";
_copydb(mostCurrent._cpublic._dbfilename);
 };
 //BA.debugLineNum = 47;BA.debugLine="If cPublic.CheckForInternet Then";
if (mostCurrent._cpublic._checkforinternet(mostCurrent.activityBA)) { 
 //BA.debugLineNum = 48;BA.debugLine="getData";
_getdata();
 }else {
 //BA.debugLineNum = 50;BA.debugLine="loadOffline";
_loadoffline();
 };
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 104;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 100;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 102;BA.debugLine="End Sub";
return "";
}
public static String  _copydb(String _databasename) throws Exception{
 //BA.debugLineNum = 56;BA.debugLine="Sub CopyDB(DataBaseName As String)";
 //BA.debugLineNum = 58;BA.debugLine="Try";
try { //BA.debugLineNum = 60;BA.debugLine="If File.Exists(File.DirInternal, DataBaseName) =";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),_databasename)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 61;BA.debugLine="Try";
try { //BA.debugLineNum = 62;BA.debugLine="File.Copy(File.DirAssets, DataBaseName, File.D";
anywheresoftware.b4a.keywords.Common.File.Copy(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),_databasename,anywheresoftware.b4a.keywords.Common.File.getDirInternal(),_databasename);
 } 
       catch (Exception e6) {
			processBA.setLastException(e6); //BA.debugLineNum = 64;BA.debugLine="Msgbox(\"خطا\", \"خطا\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("خطا"),BA.ObjectToCharSequence("خطا"),mostCurrent.activityBA);
 //BA.debugLineNum = 65;BA.debugLine="Activity.Finish";
mostCurrent._activity.Finish();
 };
 };
 //BA.debugLineNum = 70;BA.debugLine="If File.Exists(File.DirInternal, DataBaseName) T";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),_databasename)) { 
 //BA.debugLineNum = 71;BA.debugLine="Try";
try { //BA.debugLineNum = 72;BA.debugLine="ProgressDialogShow(\"صبر کنید\")";
anywheresoftware.b4a.keywords.Common.ProgressDialogShow(mostCurrent.activityBA,BA.ObjectToCharSequence("صبر کنید"));
 //BA.debugLineNum = 73;BA.debugLine="SQL1.Initialize(File.DirInternal, DataBaseName";
_sql1.Initialize(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),_databasename,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 74;BA.debugLine="ProgressDialogHide";
anywheresoftware.b4a.keywords.Common.ProgressDialogHide();
 //BA.debugLineNum = 75;BA.debugLine="If SQL1.IsInitialized = False Then";
if (_sql1.IsInitialized()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 76;BA.debugLine="Msgbox(\"خطا\", \"خطا\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("خطا"),BA.ObjectToCharSequence("خطا"),mostCurrent.activityBA);
 //BA.debugLineNum = 77;BA.debugLine="Activity.Finish";
mostCurrent._activity.Finish();
 };
 } 
       catch (Exception e20) {
			processBA.setLastException(e20); //BA.debugLineNum = 80;BA.debugLine="ProgressDialogHide";
anywheresoftware.b4a.keywords.Common.ProgressDialogHide();
 //BA.debugLineNum = 81;BA.debugLine="Msgbox(\"خطا\", \"خطا\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("خطا"),BA.ObjectToCharSequence("خطا"),mostCurrent.activityBA);
 //BA.debugLineNum = 82;BA.debugLine="Activity.Finish";
mostCurrent._activity.Finish();
 };
 }else {
 //BA.debugLineNum = 85;BA.debugLine="ProgressDialogHide";
anywheresoftware.b4a.keywords.Common.ProgressDialogHide();
 //BA.debugLineNum = 86;BA.debugLine="Msgbox(\"خطا\", \"خطا\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("خطا"),BA.ObjectToCharSequence("خطا"),mostCurrent.activityBA);
 //BA.debugLineNum = 87;BA.debugLine="Activity.Finish";
mostCurrent._activity.Finish();
 };
 } 
       catch (Exception e30) {
			processBA.setLastException(e30); //BA.debugLineNum = 90;BA.debugLine="ProgressDialogHide";
anywheresoftware.b4a.keywords.Common.ProgressDialogHide();
 //BA.debugLineNum = 91;BA.debugLine="Msgbox(\"خطا\", \"خطا\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("خطا"),BA.ObjectToCharSequence("خطا"),mostCurrent.activityBA);
 //BA.debugLineNum = 92;BA.debugLine="Activity.Finish";
mostCurrent._activity.Finish();
 };
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.PanelWrapper  _createlistitem(b4a.example.cpublic._searchresult _osearchresult) throws Exception{
anywheresoftware.b4a.objects.PanelWrapper _pnl = null;
anywheresoftware.b4a.objects.ImageViewWrapper _imgposter = null;
int _width = 0;
anywheresoftware.b4a.objects.LabelWrapper[] _lbldata = null;
int _i = 0;
 //BA.debugLineNum = 204;BA.debugLine="Sub CreateListItem( oSearchResult As SearchResult";
 //BA.debugLineNum = 206;BA.debugLine="Dim pnl As Panel";
_pnl = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 207;BA.debugLine="pnl.Initialize(\"item\")";
_pnl.Initialize(mostCurrent.activityBA,"item");
 //BA.debugLineNum = 208;BA.debugLine="pnl.Color = Starter.colorPrimary";
_pnl.setColor(mostCurrent._starter._colorprimary);
 //BA.debugLineNum = 209;BA.debugLine="pnl.Tag = oSearchResult.imdbID";
_pnl.setTag((Object)(_osearchresult.imdbID));
 //BA.debugLineNum = 211;BA.debugLine="Dim imgPoster As ImageView";
_imgposter = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 212;BA.debugLine="imgPoster.Initialize(\"\")";
_imgposter.Initialize(mostCurrent.activityBA,"");
 //BA.debugLineNum = 213;BA.debugLine="imgPoster.Gravity = Bit.Or(Gravity.CENTER, Gravit";
_imgposter.setGravity(anywheresoftware.b4a.keywords.Common.Bit.Or(anywheresoftware.b4a.keywords.Common.Gravity.CENTER,anywheresoftware.b4a.keywords.Common.Gravity.FILL));
 //BA.debugLineNum = 214;BA.debugLine="glide.Load2(oSearchResult.Poster).Apply(glide.RO.";
mostCurrent._glide.Load2(mostCurrent.activityBA,_osearchresult.Poster).Apply(mostCurrent._glide.getRO().CenterCrop()).Into(_imgposter);
 //BA.debugLineNum = 215;BA.debugLine="pnl.AddView( imgPoster, 0%x, 0, 25%x, 19%y)";
_pnl.AddView((android.view.View)(_imgposter.getObject()),anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (0),mostCurrent.activityBA),(int) (0),anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (25),mostCurrent.activityBA),anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (19),mostCurrent.activityBA));
 //BA.debugLineNum = 217;BA.debugLine="Dim  width As Int = clvMovies.AsView.Width";
_width = mostCurrent._clvmovies._asview().getWidth();
 //BA.debugLineNum = 219;BA.debugLine="Dim lblData(3)  As Label";
_lbldata = new anywheresoftware.b4a.objects.LabelWrapper[(int) (3)];
{
int d0 = _lbldata.length;
for (int i0 = 0;i0 < d0;i0++) {
_lbldata[i0] = new anywheresoftware.b4a.objects.LabelWrapper();
}
}
;
 //BA.debugLineNum = 220;BA.debugLine="For i = 0 To lblData.Length - 1";
{
final int step12 = 1;
final int limit12 = (int) (_lbldata.length-1);
_i = (int) (0) ;
for (;_i <= limit12 ;_i = _i + step12 ) {
 //BA.debugLineNum = 221;BA.debugLine="lblData(i).Initialize(\"\")";
_lbldata[_i].Initialize(mostCurrent.activityBA,"");
 //BA.debugLineNum = 222;BA.debugLine="lblData(i).TextColor = Colors.White";
_lbldata[_i].setTextColor(anywheresoftware.b4a.keywords.Common.Colors.White);
 //BA.debugLineNum = 223;BA.debugLine="lblData(i).Gravity = Bit.Or(Gravity.LEFT, Gravit";
_lbldata[_i].setGravity(anywheresoftware.b4a.keywords.Common.Bit.Or(anywheresoftware.b4a.keywords.Common.Gravity.LEFT,anywheresoftware.b4a.keywords.Common.Gravity.CENTER_VERTICAL));
 //BA.debugLineNum = 224;BA.debugLine="lblData(i).TextSize = 6%y*500/1000dip";
_lbldata[_i].setTextSize((float) (anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (6),mostCurrent.activityBA)*500/(double)anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1000))));
 //BA.debugLineNum = 225;BA.debugLine="lblData(i).Typeface = Typeface.SANS_SERIF";
_lbldata[_i].setTypeface(anywheresoftware.b4a.keywords.Common.Typeface.SANS_SERIF);
 //BA.debugLineNum = 226;BA.debugLine="lblData(i).Padding = Array As Int (10dip, 5dip,";
_lbldata[_i].setPadding(new int[]{anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5))});
 //BA.debugLineNum = 227;BA.debugLine="lblData(i).SingleLine = True";
_lbldata[_i].setSingleLine(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 229;BA.debugLine="pnl.AddView( lblData(i), 25%x,0.5%y + 6.3%y*i, w";
_pnl.AddView((android.view.View)(_lbldata[_i].getObject()),anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (25),mostCurrent.activityBA),(int) (anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (0.5),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (6.3),mostCurrent.activityBA)*_i),(int) (_width-anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (25),mostCurrent.activityBA)-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (15))),anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (6),mostCurrent.activityBA));
 }
};
 //BA.debugLineNum = 233;BA.debugLine="lblData(0).Text = oSearchResult.Title";
_lbldata[(int) (0)].setText(BA.ObjectToCharSequence(_osearchresult.Title));
 //BA.debugLineNum = 234;BA.debugLine="lblData(1).Text = oSearchResult.Year";
_lbldata[(int) (1)].setText(BA.ObjectToCharSequence(_osearchresult.Year));
 //BA.debugLineNum = 235;BA.debugLine="lblData(2).Text = oSearchResult.sType";
_lbldata[(int) (2)].setText(BA.ObjectToCharSequence(_osearchresult.sType));
 //BA.debugLineNum = 237;BA.debugLine="lblData(1).TextColor = Starter.colorSecondary";
_lbldata[(int) (1)].setTextColor(mostCurrent._starter._colorsecondary);
 //BA.debugLineNum = 238;BA.debugLine="lblData(2).TextSize = 6%y*320/1000dip";
_lbldata[(int) (2)].setTextSize((float) (anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (6),mostCurrent.activityBA)*320/(double)anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1000))));
 //BA.debugLineNum = 241;BA.debugLine="pnl.SetLayout(0, 0, width, 19%y)";
_pnl.SetLayout((int) (0),(int) (0),_width,anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (19),mostCurrent.activityBA));
 //BA.debugLineNum = 243;BA.debugLine="SetTextSize(lblData(0), lblData(0).Width - 15dip)";
_settextsize(_lbldata[(int) (0)],(int) (_lbldata[(int) (0)].getWidth()-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (15))));
 //BA.debugLineNum = 245;BA.debugLine="Return pnl";
if (true) return _pnl;
 //BA.debugLineNum = 247;BA.debugLine="End Sub";
return null;
}
public static String  _datarecived_(String _sdata) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;
String _response = "";
String _totalresults = "";
anywheresoftware.b4a.objects.collections.List _search = null;
anywheresoftware.b4a.objects.collections.Map _mpmovies = null;
anywheresoftware.b4a.objects.collections.Map _colsearch = null;
b4a.example.cpublic._searchresult _osearchresult = null;
 //BA.debugLineNum = 131;BA.debugLine="Sub DataRecived_(sData As String)";
 //BA.debugLineNum = 133;BA.debugLine="ProgressDialogHide";
anywheresoftware.b4a.keywords.Common.ProgressDialogHide();
 //BA.debugLineNum = 135;BA.debugLine="If sData.EqualsIgnoreCase(\"\") = False Then";
if (_sdata.equalsIgnoreCase("")==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 137;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 138;BA.debugLine="parser.Initialize(sData)";
_parser.Initialize(_sdata);
 //BA.debugLineNum = 140;BA.debugLine="Dim root As Map = parser.NextObject";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 141;BA.debugLine="Dim Response As String = root.Get(\"Response\")";
_response = BA.ObjectToString(_root.Get((Object)("Response")));
 //BA.debugLineNum = 142;BA.debugLine="Dim totalResults As String = root.Get(\"totalResu";
_totalresults = BA.ObjectToString(_root.Get((Object)("totalResults")));
 //BA.debugLineNum = 143;BA.debugLine="Dim Search As List = root.Get(\"Search\")";
_search = new anywheresoftware.b4a.objects.collections.List();
_search.setObject((java.util.List)(_root.Get((Object)("Search"))));
 //BA.debugLineNum = 145;BA.debugLine="Dim mpMovies As Map";
_mpmovies = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 146;BA.debugLine="mpMovies.Initialize";
_mpmovies.Initialize();
 //BA.debugLineNum = 148;BA.debugLine="For Each colSearch As Map In Search";
_colsearch = new anywheresoftware.b4a.objects.collections.Map();
{
final anywheresoftware.b4a.BA.IterableList group11 = _search;
final int groupLen11 = group11.getSize()
;int index11 = 0;
;
for (; index11 < groupLen11;index11++){
_colsearch.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(group11.Get(index11)));
 //BA.debugLineNum = 151;BA.debugLine="Try";
try { //BA.debugLineNum = 152;BA.debugLine="Dim oSearchResult As SearchResult";
_osearchresult = new b4a.example.cpublic._searchresult();
 //BA.debugLineNum = 153;BA.debugLine="oSearchResult.Initialize";
_osearchresult.Initialize();
 //BA.debugLineNum = 155;BA.debugLine="oSearchResult.Title = colSearch.Get(\"Title\")";
_osearchresult.Title = BA.ObjectToString(_colsearch.Get((Object)("Title")));
 //BA.debugLineNum = 156;BA.debugLine="oSearchResult.Year = colSearch.Get(\"Year\")";
_osearchresult.Year = BA.ObjectToString(_colsearch.Get((Object)("Year")));
 //BA.debugLineNum = 157;BA.debugLine="oSearchResult.imdbID = colSearch.Get(\"imdbID\")";
_osearchresult.imdbID = BA.ObjectToString(_colsearch.Get((Object)("imdbID")));
 //BA.debugLineNum = 158;BA.debugLine="oSearchResult.sType = colSearch.Get(\"Type\")";
_osearchresult.sType = BA.ObjectToString(_colsearch.Get((Object)("Type")));
 //BA.debugLineNum = 159;BA.debugLine="oSearchResult.Poster = colSearch.Get(\"Poster\")";
_osearchresult.Poster = BA.ObjectToString(_colsearch.Get((Object)("Poster")));
 } 
       catch (Exception e21) {
			processBA.setLastException(e21); //BA.debugLineNum = 161;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("218284574",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA)),0);
 };
 //BA.debugLineNum = 164;BA.debugLine="mpMovies.Put( oSearchResult.imdbID, oSearchResu";
_mpmovies.Put((Object)(_osearchresult.imdbID),(Object)(_osearchresult));
 }
};
 //BA.debugLineNum = 167;BA.debugLine="FillMovies(mpMovies)";
_fillmovies(_mpmovies);
 //BA.debugLineNum = 169;BA.debugLine="SaveToDb(mpMovies)";
_savetodb(_mpmovies);
 }else {
 //BA.debugLineNum = 172;BA.debugLine="ToastMessageShow(\"هیچ اطلاعاتی برای نمایش وجود ن";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("هیچ اطلاعاتی برای نمایش وجود ندارد"),anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 177;BA.debugLine="End Sub";
return "";
}
public static String  _fillmovies(anywheresoftware.b4a.objects.collections.Map _mpmovies) throws Exception{
int _i = 0;
b4a.example.cpublic._searchresult _osearchresult = null;
 //BA.debugLineNum = 180;BA.debugLine="Sub FillMovies(mpMovies As Map)";
 //BA.debugLineNum = 182;BA.debugLine="clvMovies.Clear";
mostCurrent._clvmovies._clear();
 //BA.debugLineNum = 183;BA.debugLine="Try";
try { //BA.debugLineNum = 185;BA.debugLine="If mpMovies.Size <> 0 Then";
if (_mpmovies.getSize()!=0) { 
 //BA.debugLineNum = 187;BA.debugLine="For i = 0 To mpMovies.Size - 1";
{
final int step4 = 1;
final int limit4 = (int) (_mpmovies.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit4 ;_i = _i + step4 ) {
 //BA.debugLineNum = 189;BA.debugLine="Dim oSearchResult As SearchResult";
_osearchresult = new b4a.example.cpublic._searchresult();
 //BA.debugLineNum = 190;BA.debugLine="oSearchResult = mpMovies.GetValueAt(i)";
_osearchresult = (b4a.example.cpublic._searchresult)(_mpmovies.GetValueAt(_i));
 //BA.debugLineNum = 192;BA.debugLine="clvMovies.Add( CreateListItem(oSearchResult  )";
mostCurrent._clvmovies._add((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_createlistitem(_osearchresult).getObject())),(Object)(_osearchresult.imdbID));
 }
};
 };
 } 
       catch (Exception e11) {
			processBA.setLastException(e11); //BA.debugLineNum = 199;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("218350099",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA)),0);
 };
 //BA.debugLineNum = 202;BA.debugLine="End Sub";
return "";
}
public static String  _getdata() throws Exception{
String _surl = "";
anywheresoftware.b4a.objects.collections.Map _updatelinks = null;
 //BA.debugLineNum = 108;BA.debugLine="Sub getData";
 //BA.debugLineNum = 110;BA.debugLine="If cPublic.CheckForInternet Then";
if (mostCurrent._cpublic._checkforinternet(mostCurrent.activityBA)) { 
 //BA.debugLineNum = 112;BA.debugLine="ProgressDialogShow2(\"لطفا چند لحظه صبر کنید\" , F";
anywheresoftware.b4a.keywords.Common.ProgressDialogShow2(mostCurrent.activityBA,BA.ObjectToCharSequence("لطفا چند لحظه صبر کنید"),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 113;BA.debugLine="Dim sURL As String = Starter.sBaseURL & \"&s=batm";
_surl = mostCurrent._starter._sbaseurl+"&s=batman";
 //BA.debugLineNum = 115;BA.debugLine="Try";
try { //BA.debugLineNum = 116;BA.debugLine="Dim UpdateLinks As Map";
_updatelinks = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 117;BA.debugLine="UpdateLinks.Initialize";
_updatelinks.Initialize();
 //BA.debugLineNum = 118;BA.debugLine="UpdateLinks.Put(\"getData\" , sURL)";
_updatelinks.Put((Object)("getData"),(Object)(_surl));
 //BA.debugLineNum = 120;BA.debugLine="serviceDataDownloader.TargetActivity = Me";
mostCurrent._servicedatadownloader._targetactivity = main.getObject();
 //BA.debugLineNum = 121;BA.debugLine="serviceDataDownloader.CallbackFunction = \"DataR";
mostCurrent._servicedatadownloader._callbackfunction = "DataRecived_";
 //BA.debugLineNum = 122;BA.debugLine="CallSubDelayed2(serviceDataDownloader, \"Downloa";
anywheresoftware.b4a.keywords.Common.CallSubDelayed2(processBA,(Object)(mostCurrent._servicedatadownloader.getObject()),"Download",(Object)(_updatelinks));
 } 
       catch (Exception e12) {
			processBA.setLastException(e12); //BA.debugLineNum = 124;BA.debugLine="Log(LastException.Message)";
anywheresoftware.b4a.keywords.Common.LogImpl("218219024",anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA).getMessage(),0);
 };
 };
 //BA.debugLineNum = 129;BA.debugLine="End Sub";
return "";
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 27;BA.debugLine="Dim glide As Hitex_Glide";
mostCurrent._glide = new com.glide.Hitex_Glide();
 //BA.debugLineNum = 29;BA.debugLine="Dim su As StringUtils";
mostCurrent._su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 31;BA.debugLine="Private clvMovies As CustomListView";
mostCurrent._clvmovies = new b4a.example3.customlistview();
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}
public static String  _item_click() throws Exception{
anywheresoftware.b4a.objects.PanelWrapper _osender = null;
String _sid = "";
 //BA.debugLineNum = 284;BA.debugLine="Sub item_Click";
 //BA.debugLineNum = 286;BA.debugLine="Dim oSender As Panel = Sender";
_osender = new anywheresoftware.b4a.objects.PanelWrapper();
_osender.setObject((android.view.ViewGroup)(anywheresoftware.b4a.keywords.Common.Sender(mostCurrent.activityBA)));
 //BA.debugLineNum = 287;BA.debugLine="Dim sId As String = oSender.Tag";
_sid = BA.ObjectToString(_osender.getTag());
 //BA.debugLineNum = 290;BA.debugLine="OpenStoryDetial(sId)";
_openstorydetial(_sid);
 //BA.debugLineNum = 291;BA.debugLine="End Sub";
return "";
}
public static String  _loadoffline() throws Exception{
anywheresoftware.b4a.objects.collections.Map _mpmovies = null;
 //BA.debugLineNum = 300;BA.debugLine="Sub loadOffline";
 //BA.debugLineNum = 303;BA.debugLine="Dim mpMovies As Map";
_mpmovies = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 304;BA.debugLine="mpMovies.Initialize";
_mpmovies.Initialize();
 //BA.debugLineNum = 306;BA.debugLine="mpMovies = cPublic.GetSearchResult";
_mpmovies = mostCurrent._cpublic._getsearchresult(mostCurrent.activityBA);
 //BA.debugLineNum = 308;BA.debugLine="FillMovies( mpMovies )";
_fillmovies(_mpmovies);
 //BA.debugLineNum = 309;BA.debugLine="End Sub";
return "";
}
public static String  _openstorydetial(String _sid) throws Exception{
 //BA.debugLineNum = 294;BA.debugLine="Sub OpenStoryDetial(sId As String)";
 //BA.debugLineNum = 296;BA.debugLine="CallSubDelayed2(MovieDetailActivity, \"ShowMovieDe";
anywheresoftware.b4a.keywords.Common.CallSubDelayed2(processBA,(Object)(mostCurrent._moviedetailactivity.getObject()),"ShowMovieDetails",(Object)(_sid));
 //BA.debugLineNum = 297;BA.debugLine="End Sub";
return "";
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4a.example.dateutils._process_globals();
main._process_globals();
moviedetailactivity._process_globals();
starter._process_globals();
cpublic._process_globals();
servicedatadownloader._process_globals();
httputils2service._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 18;BA.debugLine="Public SQL1 As SQL";
_sql1 = new anywheresoftware.b4a.sql.SQL();
 //BA.debugLineNum = 19;BA.debugLine="Dim tFontawesome As Typeface";
_tfontawesome = new anywheresoftware.b4a.keywords.constants.TypefaceWrapper();
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public static String  _savetodb(anywheresoftware.b4a.objects.collections.Map _mpmovies) throws Exception{
int _i = 0;
b4a.example.cpublic._searchresult _osearchresult = null;
 //BA.debugLineNum = 249;BA.debugLine="Sub SaveToDb(mpMovies As Map)";
 //BA.debugLineNum = 251;BA.debugLine="For i = 0 To mpMovies.Size-1";
{
final int step1 = 1;
final int limit1 = (int) (_mpmovies.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit1 ;_i = _i + step1 ) {
 //BA.debugLineNum = 252;BA.debugLine="Dim oSearchResult As SearchResult = mpMovies.Get";
_osearchresult = (b4a.example.cpublic._searchresult)(_mpmovies.GetValueAt(_i));
 //BA.debugLineNum = 254;BA.debugLine="If cPublic.IsSearchResultExists(oSearchResult.im";
if (mostCurrent._cpublic._issearchresultexists(mostCurrent.activityBA,_osearchresult.imdbID)) { 
 //BA.debugLineNum = 255;BA.debugLine="cPublic.UpdateSearchResult(oSearchResult)";
mostCurrent._cpublic._updatesearchresult(mostCurrent.activityBA,_osearchresult);
 }else {
 //BA.debugLineNum = 257;BA.debugLine="cPublic.AddSearchResult(oSearchResult)";
mostCurrent._cpublic._addsearchresult(mostCurrent.activityBA,_osearchresult);
 };
 }
};
 //BA.debugLineNum = 261;BA.debugLine="End Sub";
return "";
}
public static String  _settextsize(anywheresoftware.b4a.objects.LabelWrapper _lbl,int _lblwidth) throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnvs = null;
int _txtwidth = 0;
 //BA.debugLineNum = 263;BA.debugLine="Sub SetTextSize(lbl As Label, lblWidth As Int   )";
 //BA.debugLineNum = 266;BA.debugLine="Try";
try { //BA.debugLineNum = 267;BA.debugLine="Dim cnvs As Canvas";
_cnvs = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 268;BA.debugLine="cnvs.Initialize(Activity)";
_cnvs.Initialize((android.view.View)(mostCurrent._activity.getObject()));
 //BA.debugLineNum = 270;BA.debugLine="Dim txtWidth As Int = cnvs.MeasureStringWidth(lb";
_txtwidth = (int) (_cnvs.MeasureStringWidth(_lbl.getText(),_lbl.getTypeface(),_lbl.getTextSize()));
 //BA.debugLineNum = 272;BA.debugLine="If txtWidth > lblWidth Then";
if (_txtwidth>_lblwidth) { 
 //BA.debugLineNum = 273;BA.debugLine="Do While txtWidth > lblWidth";
while (_txtwidth>_lblwidth) {
 //BA.debugLineNum = 274;BA.debugLine="lbl.TextSize = lbl.TextSize- 0.2";
_lbl.setTextSize((float) (_lbl.getTextSize()-0.2));
 //BA.debugLineNum = 275;BA.debugLine="txtWidth = cnvs.MeasureStringWidth(lbl.Text ,";
_txtwidth = (int) (_cnvs.MeasureStringWidth(_lbl.getText(),_lbl.getTypeface(),_lbl.getTextSize()));
 }
;
 };
 } 
       catch (Exception e12) {
			processBA.setLastException(e12); //BA.debugLineNum = 279;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("218546704",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA)),0);
 };
 //BA.debugLineNum = 282;BA.debugLine="End Sub";
return "";
}
}
