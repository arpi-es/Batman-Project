package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class cpublic {
private static cpublic mostCurrent = new cpublic();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static String _dbfilename = "";
public static String _tblsearchresult = "";
public static String _tblmovie = "";
public b4a.example.dateutils _dateutils = null;
public b4a.example.main _main = null;
public b4a.example.moviedetailactivity _moviedetailactivity = null;
public b4a.example.starter _starter = null;
public b4a.example.servicedatadownloader _servicedatadownloader = null;
public b4a.example.httputils2service _httputils2service = null;
public static class _searchresult{
public boolean IsInitialized;
public String imdbID;
public String Title;
public String Year;
public String sType;
public String Poster;
public void Initialize() {
IsInitialized = true;
imdbID = "";
Title = "";
Year = "";
sType = "";
Poster = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _movie{
public boolean IsInitialized;
public String imdbID;
public String Title;
public String Year;
public String sType;
public String Poster;
public String Actors;
public String Plot;
public String Director;
public String Writer;
public String Language;
public String imdbRating;
public void Initialize() {
IsInitialized = true;
imdbID = "";
Title = "";
Year = "";
sType = "";
Poster = "";
Actors = "";
Plot = "";
Director = "";
Writer = "";
Language = "";
imdbRating = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _addmovie(anywheresoftware.b4a.BA _ba,b4a.example.cpublic._movie _omovie) throws Exception{
String _squery = "";
 //BA.debugLineNum = 168;BA.debugLine="Sub AddMovie(oMovie As Movie)";
 //BA.debugLineNum = 170;BA.debugLine="Try";
try { //BA.debugLineNum = 171;BA.debugLine="Dim sQuery As String";
_squery = "";
 //BA.debugLineNum = 172;BA.debugLine="sQuery = \"INSERT INTO \" & tblMovie & \" VALUES (?";
_squery = "INSERT INTO "+_tblmovie+" VALUES (?,?,?,?,?,?,?,?,?,?,? )";
 //BA.debugLineNum = 173;BA.debugLine="Main.SQL1.ExecNonQuery2(sQuery, Array As String(";
mostCurrent._main._sql1.ExecNonQuery2(_squery,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_omovie.imdbID,_omovie.Title,_omovie.Year,_omovie.sType,_omovie.Poster,_omovie.Actors,_omovie.Plot,_omovie.Director,_omovie.Writer,_omovie.Language,_omovie.imdbRating}));
 } 
       catch (Exception e6) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e6); //BA.debugLineNum = 176;BA.debugLine="Log(LastException.Message)";
anywheresoftware.b4a.keywords.Common.LogImpl("219660808",anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage(),0);
 };
 //BA.debugLineNum = 179;BA.debugLine="End Sub";
return "";
}
public static String  _addsearchresult(anywheresoftware.b4a.BA _ba,b4a.example.cpublic._searchresult _osearchresult) throws Exception{
String _squery = "";
 //BA.debugLineNum = 80;BA.debugLine="Sub AddSearchResult(oSearchResult As SearchResult)";
 //BA.debugLineNum = 82;BA.debugLine="Try";
try { //BA.debugLineNum = 83;BA.debugLine="Dim sQuery As String";
_squery = "";
 //BA.debugLineNum = 84;BA.debugLine="sQuery = \"INSERT INTO \" & tblSearchResult & \" VA";
_squery = "INSERT INTO "+_tblsearchresult+" VALUES (?, ?, ?, ?, ? )";
 //BA.debugLineNum = 85;BA.debugLine="Main.SQL1.ExecNonQuery2(sQuery, Array As String(";
mostCurrent._main._sql1.ExecNonQuery2(_squery,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_osearchresult.imdbID,_osearchresult.Title,_osearchresult.Year,_osearchresult.sType,_osearchresult.Poster}));
 } 
       catch (Exception e6) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e6); //BA.debugLineNum = 88;BA.debugLine="Log(LastException.Message)";
anywheresoftware.b4a.keywords.Common.LogImpl("219791880",anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage(),0);
 };
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return "";
}
public static boolean  _checkforinternet(anywheresoftware.b4a.BA _ba) throws Exception{
wifi.MLwifi _mwifi = null;
 //BA.debugLineNum = 24;BA.debugLine="Sub CheckForInternet As Boolean";
 //BA.debugLineNum = 26;BA.debugLine="Dim mWiFi As MLwifi";
_mwifi = new wifi.MLwifi();
 //BA.debugLineNum = 27;BA.debugLine="Return mWiFi.isOnLine";
if (true) return _mwifi.isOnLine((_ba.processBA == null ? _ba : _ba.processBA));
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return false;
}
public static b4a.example.cpublic._movie  _getmovie(anywheresoftware.b4a.BA _ba,String _sid) throws Exception{
b4a.example.cpublic._movie _omovie = null;
anywheresoftware.b4a.sql.SQL.CursorWrapper _ocursor = null;
 //BA.debugLineNum = 181;BA.debugLine="Sub GetMovie(sID As String)  As Movie";
 //BA.debugLineNum = 183;BA.debugLine="Dim oMovie As Movie";
_omovie = new b4a.example.cpublic._movie();
 //BA.debugLineNum = 184;BA.debugLine="oMovie.Initialize";
_omovie.Initialize();
 //BA.debugLineNum = 185;BA.debugLine="oMovie.imdbID = \"-1\"";
_omovie.imdbID = "-1";
 //BA.debugLineNum = 186;BA.debugLine="Try";
try { //BA.debugLineNum = 187;BA.debugLine="Dim  oCursor As Cursor";
_ocursor = new anywheresoftware.b4a.sql.SQL.CursorWrapper();
 //BA.debugLineNum = 188;BA.debugLine="oCursor = Main.sql1.ExecQuery(\"Select * From \" &";
_ocursor.setObject((android.database.Cursor)(mostCurrent._main._sql1.ExecQuery("Select * From "+_tblmovie+" Where imdbID = '"+_sid+"'")));
 //BA.debugLineNum = 190;BA.debugLine="If oCursor.RowCount <> 0 Then";
if (_ocursor.getRowCount()!=0) { 
 //BA.debugLineNum = 192;BA.debugLine="oCursor.Position = 0";
_ocursor.setPosition((int) (0));
 //BA.debugLineNum = 193;BA.debugLine="oMovie.imdbID = oCursor.GetString(\"imdbID\")";
_omovie.imdbID = _ocursor.GetString("imdbID");
 //BA.debugLineNum = 194;BA.debugLine="oMovie.Title = oCursor.GetString(\"Title\")";
_omovie.Title = _ocursor.GetString("Title");
 //BA.debugLineNum = 195;BA.debugLine="oMovie.Year = oCursor.GetString(\"Year\")";
_omovie.Year = _ocursor.GetString("Year");
 //BA.debugLineNum = 196;BA.debugLine="oMovie.sType = oCursor.GetString(\"sType\")";
_omovie.sType = _ocursor.GetString("sType");
 //BA.debugLineNum = 197;BA.debugLine="oMovie.Poster = oCursor.GetString(\"Poster\")";
_omovie.Poster = _ocursor.GetString("Poster");
 //BA.debugLineNum = 198;BA.debugLine="oMovie.Actors = oCursor.GetString(\"Actors\")";
_omovie.Actors = _ocursor.GetString("Actors");
 //BA.debugLineNum = 199;BA.debugLine="oMovie.Plot = oCursor.GetString(\"Plot\")";
_omovie.Plot = _ocursor.GetString("Plot");
 //BA.debugLineNum = 200;BA.debugLine="oMovie.Director = oCursor.GetString(\"Director\")";
_omovie.Director = _ocursor.GetString("Director");
 //BA.debugLineNum = 201;BA.debugLine="oMovie.Writer = oCursor.GetString(\"Writer\")";
_omovie.Writer = _ocursor.GetString("Writer");
 //BA.debugLineNum = 202;BA.debugLine="oMovie.Language = oCursor.GetString(\"Language\")";
_omovie.Language = _ocursor.GetString("Language");
 //BA.debugLineNum = 203;BA.debugLine="oMovie.imdbRating = oCursor.GetString(\"imdbRati";
_omovie.imdbRating = _ocursor.GetString("imdbRating");
 };
 //BA.debugLineNum = 206;BA.debugLine="oCursor.Close";
_ocursor.Close();
 } 
       catch (Exception e23) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e23); //BA.debugLineNum = 209;BA.debugLine="Log(LastException.Message)";
anywheresoftware.b4a.keywords.Common.LogImpl("220578332",anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage(),0);
 };
 //BA.debugLineNum = 213;BA.debugLine="Return oMovie";
if (true) return _omovie;
 //BA.debugLineNum = 215;BA.debugLine="End Sub";
return null;
}
public static anywheresoftware.b4a.objects.collections.Map  _getsearchresult(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.collections.Map _mpresult = null;
anywheresoftware.b4a.sql.SQL.CursorWrapper _ocursor = null;
int _i = 0;
b4a.example.cpublic._searchresult _osearchresult = null;
 //BA.debugLineNum = 93;BA.debugLine="Sub GetSearchResult As Map";
 //BA.debugLineNum = 95;BA.debugLine="Dim mpResult As Map";
_mpresult = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 96;BA.debugLine="mpResult.Initialize";
_mpresult.Initialize();
 //BA.debugLineNum = 98;BA.debugLine="Try";
try { //BA.debugLineNum = 99;BA.debugLine="Dim  oCursor As Cursor";
_ocursor = new anywheresoftware.b4a.sql.SQL.CursorWrapper();
 //BA.debugLineNum = 100;BA.debugLine="oCursor = Main.sql1.ExecQuery(\"Select * From \" &";
_ocursor.setObject((android.database.Cursor)(mostCurrent._main._sql1.ExecQuery("Select * From "+_tblsearchresult)));
 //BA.debugLineNum = 101;BA.debugLine="Dim i As Int";
_i = 0;
 //BA.debugLineNum = 103;BA.debugLine="For i = 0 To oCursor.RowCount - 1";
{
final int step7 = 1;
final int limit7 = (int) (_ocursor.getRowCount()-1);
_i = (int) (0) ;
for (;_i <= limit7 ;_i = _i + step7 ) {
 //BA.debugLineNum = 104;BA.debugLine="oCursor.Position = i";
_ocursor.setPosition(_i);
 //BA.debugLineNum = 106;BA.debugLine="Dim oSearchResult As SearchResult";
_osearchresult = new b4a.example.cpublic._searchresult();
 //BA.debugLineNum = 107;BA.debugLine="oSearchResult.Initialize";
_osearchresult.Initialize();
 //BA.debugLineNum = 108;BA.debugLine="oSearchResult.imdbID = oCursor.GetString(\"imdbI";
_osearchresult.imdbID = _ocursor.GetString("imdbID");
 //BA.debugLineNum = 109;BA.debugLine="oSearchResult.Title = oCursor.GetString(\"Title\"";
_osearchresult.Title = _ocursor.GetString("Title");
 //BA.debugLineNum = 110;BA.debugLine="oSearchResult.Year = oCursor.GetString(\"Year\")";
_osearchresult.Year = _ocursor.GetString("Year");
 //BA.debugLineNum = 111;BA.debugLine="oSearchResult.sType = oCursor.GetString(\"sType\"";
_osearchresult.sType = _ocursor.GetString("sType");
 //BA.debugLineNum = 112;BA.debugLine="oSearchResult.Poster = oCursor.GetString(\"Poste";
_osearchresult.Poster = _ocursor.GetString("Poster");
 //BA.debugLineNum = 114;BA.debugLine="mpResult.Put( oSearchResult.imdbID, oSearchResu";
_mpresult.Put((Object)(_osearchresult.imdbID),(Object)(_osearchresult));
 }
};
 //BA.debugLineNum = 117;BA.debugLine="oCursor.Close";
_ocursor.Close();
 } 
       catch (Exception e20) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e20); //BA.debugLineNum = 120;BA.debugLine="Log(LastException.Message)";
anywheresoftware.b4a.keywords.Common.LogImpl("220185115",anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage(),0);
 };
 //BA.debugLineNum = 124;BA.debugLine="Return mpResult";
if (true) return _mpresult;
 //BA.debugLineNum = 126;BA.debugLine="End Sub";
return null;
}
public static String  _initdatabase(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Sub initDataBase";
 //BA.debugLineNum = 32;BA.debugLine="Try";
try { //BA.debugLineNum = 33;BA.debugLine="If Main.sql1.IsInitialized = False Then";
if (mostCurrent._main._sql1.IsInitialized()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 34;BA.debugLine="Main.sql1.Initialize(File.DirInternal, DBFileNa";
mostCurrent._main._sql1.Initialize(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),_dbfilename,anywheresoftware.b4a.keywords.Common.False);
 };
 } 
       catch (Exception e6) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e6); //BA.debugLineNum = 37;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("21572870",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(_ba)),0);
 };
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return "";
}
public static String  _inittypeface(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 17;BA.debugLine="Sub initTypeface";
 //BA.debugLineNum = 19;BA.debugLine="If Main.tFontawesome.IsInitialized = False Then";
if (mostCurrent._main._tfontawesome.IsInitialized()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 20;BA.debugLine="Main.tFontawesome = Typeface.LoadFromAssets(\"fon";
mostCurrent._main._tfontawesome.setObject((android.graphics.Typeface)(anywheresoftware.b4a.keywords.Common.Typeface.LoadFromAssets("fontawesome-webfont.ttf")));
 };
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public static boolean  _ismovieexists(anywheresoftware.b4a.BA _ba,String _id) throws Exception{
boolean _bexists = false;
anywheresoftware.b4a.sql.SQL.CursorWrapper _cursor = null;
 //BA.debugLineNum = 128;BA.debugLine="Sub IsMovieExists(ID As String) As Boolean";
 //BA.debugLineNum = 130;BA.debugLine="Dim bExists As Boolean : bExists = False";
_bexists = false;
 //BA.debugLineNum = 130;BA.debugLine="Dim bExists As Boolean : bExists = False";
_bexists = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 132;BA.debugLine="initDataBase";
_initdatabase(_ba);
 //BA.debugLineNum = 134;BA.debugLine="Try";
try { //BA.debugLineNum = 135;BA.debugLine="Dim Cursor As Cursor";
_cursor = new anywheresoftware.b4a.sql.SQL.CursorWrapper();
 //BA.debugLineNum = 136;BA.debugLine="Cursor = Main.SQL1.ExecQuery(\"Select imdbID FROM";
_cursor.setObject((android.database.Cursor)(mostCurrent._main._sql1.ExecQuery("Select imdbID FROM "+_tblmovie+" Where imdbID = '"+_id+"'")));
 //BA.debugLineNum = 138;BA.debugLine="If Cursor.RowCount > 0 Then";
if (_cursor.getRowCount()>0) { 
 //BA.debugLineNum = 139;BA.debugLine="bExists = True";
_bexists = anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 141;BA.debugLine="bExists = False";
_bexists = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 144;BA.debugLine="Cursor.Close";
_cursor.Close();
 } 
       catch (Exception e14) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e14); };
 //BA.debugLineNum = 148;BA.debugLine="Return bExists";
if (true) return _bexists;
 //BA.debugLineNum = 150;BA.debugLine="End Sub";
return false;
}
public static boolean  _issearchresultexists(anywheresoftware.b4a.BA _ba,String _id) throws Exception{
boolean _bexists = false;
anywheresoftware.b4a.sql.SQL.CursorWrapper _cursor = null;
 //BA.debugLineNum = 43;BA.debugLine="Sub IsSearchResultExists(ID As String) As Boolean";
 //BA.debugLineNum = 45;BA.debugLine="Dim bExists As Boolean : bExists = False";
_bexists = false;
 //BA.debugLineNum = 45;BA.debugLine="Dim bExists As Boolean : bExists = False";
_bexists = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 47;BA.debugLine="initDataBase";
_initdatabase(_ba);
 //BA.debugLineNum = 49;BA.debugLine="Try";
try { //BA.debugLineNum = 50;BA.debugLine="Dim Cursor As Cursor";
_cursor = new anywheresoftware.b4a.sql.SQL.CursorWrapper();
 //BA.debugLineNum = 51;BA.debugLine="Cursor = Main.SQL1.ExecQuery(\"Select imdbID FROM";
_cursor.setObject((android.database.Cursor)(mostCurrent._main._sql1.ExecQuery("Select imdbID FROM "+_tblsearchresult+" Where imdbID = '"+_id+"'")));
 //BA.debugLineNum = 53;BA.debugLine="If Cursor.RowCount > 0 Then";
if (_cursor.getRowCount()>0) { 
 //BA.debugLineNum = 54;BA.debugLine="bExists = True";
_bexists = anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 56;BA.debugLine="bExists = False";
_bexists = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 59;BA.debugLine="Cursor.Close";
_cursor.Close();
 } 
       catch (Exception e14) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e14); };
 //BA.debugLineNum = 63;BA.debugLine="Return bExists";
if (true) return _bexists;
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return false;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Type SearchResult(imdbID As String, Title As Stri";
;
 //BA.debugLineNum = 9;BA.debugLine="Type Movie ( imdbID As String, Title As String, Y";
;
 //BA.debugLineNum = 12;BA.debugLine="Public DBFileName As String       = \"dbmain.db\"";
_dbfilename = "dbmain.db";
 //BA.debugLineNum = 13;BA.debugLine="Public tblSearchResult As String = \"tblSearchResu";
_tblsearchresult = "tblSearchResult";
 //BA.debugLineNum = 14;BA.debugLine="Public tblMovie As String = \"tblMovie\"";
_tblmovie = "tblMovie";
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}
public static String  _updatemovie(anywheresoftware.b4a.BA _ba,b4a.example.cpublic._movie _omovie) throws Exception{
String _squery = "";
 //BA.debugLineNum = 152;BA.debugLine="Sub UpdateMovie(oMovie As Movie)";
 //BA.debugLineNum = 154;BA.debugLine="Try";
try { //BA.debugLineNum = 155;BA.debugLine="Dim sQuery As String";
_squery = "";
 //BA.debugLineNum = 156;BA.debugLine="sQuery = \"UPDATE \" & tblMovie & \" Set Title = ?,";
_squery = "UPDATE "+_tblmovie+" Set Title = ?, Year = ?, sType = ?, Poster = ?,"+"Actors = ?, Plot = ?, Director = ?, Writer = ?,Language = ?, imdbRating = ?"+" WHERE imdbID = '"+_omovie.imdbID+"'";
 //BA.debugLineNum = 159;BA.debugLine="Main.SQL1.ExecNonQuery2(sQuery, Array As String(";
mostCurrent._main._sql1.ExecNonQuery2(_squery,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_omovie.Title,_omovie.Year,_omovie.sType,_omovie.Poster,_omovie.Actors,_omovie.Plot,_omovie.Director,_omovie.Writer,_omovie.Language,_omovie.imdbRating}));
 } 
       catch (Exception e6) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e6); //BA.debugLineNum = 163;BA.debugLine="Log(LastException.Message)";
anywheresoftware.b4a.keywords.Common.LogImpl("219595275",anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage(),0);
 };
 //BA.debugLineNum = 166;BA.debugLine="End Sub";
return "";
}
public static String  _updatesearchresult(anywheresoftware.b4a.BA _ba,b4a.example.cpublic._searchresult _osearchresult) throws Exception{
String _squery = "";
 //BA.debugLineNum = 67;BA.debugLine="Sub UpdateSearchResult(oSearchResult As SearchResu";
 //BA.debugLineNum = 69;BA.debugLine="Try";
try { //BA.debugLineNum = 70;BA.debugLine="Dim sQuery As String";
_squery = "";
 //BA.debugLineNum = 71;BA.debugLine="sQuery = \"UPDATE \" & tblSearchResult & \" Set Tit";
_squery = "UPDATE "+_tblsearchresult+" Set Title = ?, Year = ?, sType = ?, Poster = ? WHERE imdbID = '"+_osearchresult.imdbID+"'";
 //BA.debugLineNum = 72;BA.debugLine="Main.SQL1.ExecNonQuery2(sQuery, Array As String(";
mostCurrent._main._sql1.ExecNonQuery2(_squery,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_osearchresult.Title,_osearchresult.Year,_osearchresult.sType,_osearchresult.Poster}));
 } 
       catch (Exception e6) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e6); //BA.debugLineNum = 75;BA.debugLine="Log(LastException.Message)";
anywheresoftware.b4a.keywords.Common.LogImpl("219726344",anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage(),0);
 };
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
}
