package b4a.example;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class moviedetailactivity extends Activity implements B4AActivity{
	public static moviedetailactivity mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "b4a.example", "b4a.example.moviedetailactivity");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (moviedetailactivity).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "b4a.example", "b4a.example.moviedetailactivity");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.example.moviedetailactivity", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (moviedetailactivity) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (moviedetailactivity) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return moviedetailactivity.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        BA.LogInfo("** Activity (moviedetailactivity) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            moviedetailactivity mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (moviedetailactivity) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public com.glide.Hitex_Glide _glide = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblheader = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlheader = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlholder = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlinfo = null;
public static String _selectedid = "";
public b4a.example.dateutils _dateutils = null;
public b4a.example.main _main = null;
public b4a.example.starter _starter = null;
public b4a.example.cpublic _cpublic = null;
public b4a.example.servicedatadownloader _servicedatadownloader = null;
public b4a.example.httputils2service _httputils2service = null;

public static void initializeProcessGlobals() {
             try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
}
public static String  _activity_create(boolean _firsttime) throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
 //BA.debugLineNum = 34;BA.debugLine="cPublic.initTypeface";
mostCurrent._cpublic._inittypeface(mostCurrent.activityBA);
 //BA.debugLineNum = 36;BA.debugLine="Activity.LoadLayout(\"page_detail\")";
mostCurrent._activity.LoadLayout("page_detail",mostCurrent.activityBA);
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return "";
}
public static String  _datarecived_(String _sdata) throws Exception{
b4a.example.cpublic._movie _omovie = null;
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _root = null;
String _response = "";
String _title = "";
String _year = "";
String _rated = "";
String _released = "";
String _runtime = "";
String _genre = "";
String _director = "";
String _writer = "";
String _actors = "";
String _plot = "";
String _language = "";
String _country = "";
String _awards = "";
String _poster = "";
anywheresoftware.b4a.objects.collections.List _ratings = null;
anywheresoftware.b4a.objects.collections.Map _colratings = null;
String _value = "";
String _source = "";
String _metascore = "";
String _imdbrating = "";
String _imdbvotes = "";
String _imdbid = "";
String _stype = "";
String _dvd = "";
String _boxoffice = "";
String _production = "";
String _website = "";
 //BA.debugLineNum = 83;BA.debugLine="Sub DataRecived_(sData As String)";
 //BA.debugLineNum = 85;BA.debugLine="ProgressDialogHide";
anywheresoftware.b4a.keywords.Common.ProgressDialogHide();
 //BA.debugLineNum = 88;BA.debugLine="Dim oMovie As Movie";
_omovie = new b4a.example.cpublic._movie();
 //BA.debugLineNum = 89;BA.debugLine="oMovie.Initialize";
_omovie.Initialize();
 //BA.debugLineNum = 90;BA.debugLine="oMovie.imdbID = -1";
_omovie.imdbID = BA.NumberToString(-1);
 //BA.debugLineNum = 92;BA.debugLine="If sData.EqualsIgnoreCase(\"\") = False Then";
if (_sdata.equalsIgnoreCase("")==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 95;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 96;BA.debugLine="parser.Initialize(sData)";
_parser.Initialize(_sdata);
 //BA.debugLineNum = 97;BA.debugLine="Dim root As Map = parser.NextObject";
_root = new anywheresoftware.b4a.objects.collections.Map();
_root = _parser.NextObject();
 //BA.debugLineNum = 98;BA.debugLine="Dim Response As String = root.Get(\"Response\")";
_response = BA.ObjectToString(_root.Get((Object)("Response")));
 //BA.debugLineNum = 101;BA.debugLine="If Response.EqualsIgnoreCase(\"True\") Then";
if (_response.equalsIgnoreCase("True")) { 
 //BA.debugLineNum = 103;BA.debugLine="Dim Title As String = root.Get(\"Title\")";
_title = BA.ObjectToString(_root.Get((Object)("Title")));
 //BA.debugLineNum = 104;BA.debugLine="Dim Year As String = root.Get(\"Year\")";
_year = BA.ObjectToString(_root.Get((Object)("Year")));
 //BA.debugLineNum = 105;BA.debugLine="Dim Rated As String = root.Get(\"Rated\")";
_rated = BA.ObjectToString(_root.Get((Object)("Rated")));
 //BA.debugLineNum = 106;BA.debugLine="Dim Released As String = root.Get(\"Released\")";
_released = BA.ObjectToString(_root.Get((Object)("Released")));
 //BA.debugLineNum = 107;BA.debugLine="Dim Runtime As String = root.Get(\"Runtime\")";
_runtime = BA.ObjectToString(_root.Get((Object)("Runtime")));
 //BA.debugLineNum = 108;BA.debugLine="Dim Genre As String = root.Get(\"Genre\")";
_genre = BA.ObjectToString(_root.Get((Object)("Genre")));
 //BA.debugLineNum = 109;BA.debugLine="Dim Director As String = root.Get(\"Director\")";
_director = BA.ObjectToString(_root.Get((Object)("Director")));
 //BA.debugLineNum = 110;BA.debugLine="Dim Writer As String = root.Get(\"Writer\")";
_writer = BA.ObjectToString(_root.Get((Object)("Writer")));
 //BA.debugLineNum = 111;BA.debugLine="Dim Actors As String = root.Get(\"Actors\")";
_actors = BA.ObjectToString(_root.Get((Object)("Actors")));
 //BA.debugLineNum = 112;BA.debugLine="Dim Plot As String = root.Get(\"Plot\")";
_plot = BA.ObjectToString(_root.Get((Object)("Plot")));
 //BA.debugLineNum = 113;BA.debugLine="Dim Language As String = root.Get(\"Language\")";
_language = BA.ObjectToString(_root.Get((Object)("Language")));
 //BA.debugLineNum = 114;BA.debugLine="Dim Country As String = root.Get(\"Country\")";
_country = BA.ObjectToString(_root.Get((Object)("Country")));
 //BA.debugLineNum = 115;BA.debugLine="Dim Awards As String = root.Get(\"Awards\")";
_awards = BA.ObjectToString(_root.Get((Object)("Awards")));
 //BA.debugLineNum = 116;BA.debugLine="Dim Poster As String = root.Get(\"Poster\")";
_poster = BA.ObjectToString(_root.Get((Object)("Poster")));
 //BA.debugLineNum = 117;BA.debugLine="Dim Ratings As List = root.Get(\"Ratings\")";
_ratings = new anywheresoftware.b4a.objects.collections.List();
_ratings.setObject((java.util.List)(_root.Get((Object)("Ratings"))));
 //BA.debugLineNum = 118;BA.debugLine="For Each colRatings As Map In Ratings";
_colratings = new anywheresoftware.b4a.objects.collections.Map();
{
final anywheresoftware.b4a.BA.IterableList group26 = _ratings;
final int groupLen26 = group26.getSize()
;int index26 = 0;
;
for (; index26 < groupLen26;index26++){
_colratings.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(group26.Get(index26)));
 //BA.debugLineNum = 119;BA.debugLine="Dim Value As String = colRatings.Get(\"Value\")";
_value = BA.ObjectToString(_colratings.Get((Object)("Value")));
 //BA.debugLineNum = 120;BA.debugLine="Dim Source As String = colRatings.Get(\"Source\"";
_source = BA.ObjectToString(_colratings.Get((Object)("Source")));
 }
};
 //BA.debugLineNum = 123;BA.debugLine="Dim Metascore As String = root.Get(\"Metascore\")";
_metascore = BA.ObjectToString(_root.Get((Object)("Metascore")));
 //BA.debugLineNum = 124;BA.debugLine="Dim imdbRating As String = root.Get(\"imdbRating";
_imdbrating = BA.ObjectToString(_root.Get((Object)("imdbRating")));
 //BA.debugLineNum = 125;BA.debugLine="Dim imdbVotes As String = root.Get(\"imdbVotes\")";
_imdbvotes = BA.ObjectToString(_root.Get((Object)("imdbVotes")));
 //BA.debugLineNum = 126;BA.debugLine="Dim imdbID As String = root.Get(\"imdbID\")";
_imdbid = BA.ObjectToString(_root.Get((Object)("imdbID")));
 //BA.debugLineNum = 127;BA.debugLine="Dim sType As String = root.Get(\"Type\")";
_stype = BA.ObjectToString(_root.Get((Object)("Type")));
 //BA.debugLineNum = 128;BA.debugLine="Dim DVD As String = root.Get(\"DVD\")";
_dvd = BA.ObjectToString(_root.Get((Object)("DVD")));
 //BA.debugLineNum = 129;BA.debugLine="Dim BoxOffice As String = root.Get(\"BoxOffice\")";
_boxoffice = BA.ObjectToString(_root.Get((Object)("BoxOffice")));
 //BA.debugLineNum = 130;BA.debugLine="Dim Production As String = root.Get(\"Production";
_production = BA.ObjectToString(_root.Get((Object)("Production")));
 //BA.debugLineNum = 131;BA.debugLine="Dim Website As String = root.Get(\"Website\")";
_website = BA.ObjectToString(_root.Get((Object)("Website")));
 //BA.debugLineNum = 135;BA.debugLine="oMovie.imdbID = imdbID";
_omovie.imdbID = _imdbid;
 //BA.debugLineNum = 136;BA.debugLine="oMovie.Title = Title";
_omovie.Title = _title;
 //BA.debugLineNum = 137;BA.debugLine="oMovie.Year = Year";
_omovie.Year = _year;
 //BA.debugLineNum = 138;BA.debugLine="oMovie.sType = sType";
_omovie.sType = _stype;
 //BA.debugLineNum = 139;BA.debugLine="oMovie.Poster = Poster";
_omovie.Poster = _poster;
 //BA.debugLineNum = 140;BA.debugLine="oMovie.Actors = Actors";
_omovie.Actors = _actors;
 //BA.debugLineNum = 141;BA.debugLine="oMovie.Plot = Plot";
_omovie.Plot = _plot;
 //BA.debugLineNum = 142;BA.debugLine="oMovie.Director = Director";
_omovie.Director = _director;
 //BA.debugLineNum = 143;BA.debugLine="oMovie.Writer = Writer";
_omovie.Writer = _writer;
 //BA.debugLineNum = 144;BA.debugLine="oMovie.Language = Language";
_omovie.Language = _language;
 //BA.debugLineNum = 145;BA.debugLine="oMovie.imdbRating = imdbRating";
_omovie.imdbRating = _imdbrating;
 //BA.debugLineNum = 147;BA.debugLine="FillMovieDetail(oMovie)";
_fillmoviedetail(_omovie);
 //BA.debugLineNum = 148;BA.debugLine="SaveToDb(oMovie)";
_savetodb(_omovie);
 };
 }else {
 //BA.debugLineNum = 154;BA.debugLine="LoadOffline(SelectedID)";
_loadoffline(mostCurrent._selectedid);
 };
 //BA.debugLineNum = 158;BA.debugLine="End Sub";
return "";
}
public static String  _fillmoviedetail(b4a.example.cpublic._movie _omovie) throws Exception{
int _width = 0;
anywheresoftware.b4a.objects.LabelWrapper _lblinfo = null;
anywheresoftware.b4a.objects.HorizontalScrollViewWrapper _hsvactors = null;
anywheresoftware.b4a.objects.ImageViewWrapper _imgposter = null;
anywheresoftware.b4a.objects.LabelWrapper[] _lbldata = null;
int _i = 0;
int _rateint = 0;
int _ratedec = 0;
float _frate = 0f;
anywheresoftware.b4a.objects.LabelWrapper _lblstar = null;
anywheresoftware.b4a.objects.ScrollViewWrapper _svdetail = null;
anywheresoftware.b4a.objects.CSBuilder _cs = null;
anywheresoftware.b4a.objects.StringUtils _su = null;
anywheresoftware.b4a.objects.collections.List _lstdata = null;
anywheresoftware.b4a.objects.collections.List _lsttitle = null;
int _intheight = 0;
anywheresoftware.b4a.objects.LabelWrapper[] _lbldetail = null;
 //BA.debugLineNum = 160;BA.debugLine="Sub FillMovieDetail(oMovie As Movie)";
 //BA.debugLineNum = 161;BA.debugLine="Dim width As Int = pnlInfo.Width";
_width = mostCurrent._pnlinfo.getWidth();
 //BA.debugLineNum = 164;BA.debugLine="If oMovie.imdbID = \"-1\" Then";
if ((_omovie.imdbID).equals("-1")) { 
 //BA.debugLineNum = 166;BA.debugLine="Dim lblInfo As Label";
_lblinfo = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 167;BA.debugLine="lblInfo.Initialize(\"\")";
_lblinfo.Initialize(mostCurrent.activityBA,"");
 //BA.debugLineNum = 168;BA.debugLine="lblInfo.TextColor = Colors.White";
_lblinfo.setTextColor(anywheresoftware.b4a.keywords.Common.Colors.White);
 //BA.debugLineNum = 169;BA.debugLine="lblInfo.Gravity = Bit.Or(Gravity.LEFT, Gravity.T";
_lblinfo.setGravity(anywheresoftware.b4a.keywords.Common.Bit.Or(anywheresoftware.b4a.keywords.Common.Gravity.LEFT,anywheresoftware.b4a.keywords.Common.Gravity.TOP));
 //BA.debugLineNum = 170;BA.debugLine="lblInfo.TextSize = 6%y*500/1000dip";
_lblinfo.setTextSize((float) (anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (6),mostCurrent.activityBA)*500/(double)anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1000))));
 //BA.debugLineNum = 171;BA.debugLine="lblInfo.Typeface = Typeface.SANS_SERIF";
_lblinfo.setTypeface(anywheresoftware.b4a.keywords.Common.Typeface.SANS_SERIF);
 //BA.debugLineNum = 172;BA.debugLine="lblInfo.Padding = Array As Int (10dip, 5dip, 5di";
_lblinfo.setPadding(new int[]{anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5))});
 //BA.debugLineNum = 174;BA.debugLine="lblInfo.Text = \"No Data Found.\" & CRLF & \"Check";
_lblinfo.setText(BA.ObjectToCharSequence("No Data Found."+anywheresoftware.b4a.keywords.Common.CRLF+"Check your internet connection & try again."));
 //BA.debugLineNum = 175;BA.debugLine="pnlInfo.AddView( lblInfo, 2%x,0.5%y   , width-4%";
mostCurrent._pnlinfo.AddView((android.view.View)(_lblinfo.getObject()),anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (2),mostCurrent.activityBA),anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (0.5),mostCurrent.activityBA),(int) (_width-anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (4),mostCurrent.activityBA)),(int) (-2));
 }else {
 //BA.debugLineNum = 179;BA.debugLine="Dim hsvActors As HorizontalScrollView";
_hsvactors = new anywheresoftware.b4a.objects.HorizontalScrollViewWrapper();
 //BA.debugLineNum = 181;BA.debugLine="Dim imgPoster As ImageView";
_imgposter = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 182;BA.debugLine="imgPoster.Initialize(\"\")";
_imgposter.Initialize(mostCurrent.activityBA,"");
 //BA.debugLineNum = 183;BA.debugLine="imgPoster.Gravity = Bit.Or(Gravity.CENTER, Gravi";
_imgposter.setGravity(anywheresoftware.b4a.keywords.Common.Bit.Or(anywheresoftware.b4a.keywords.Common.Gravity.CENTER,anywheresoftware.b4a.keywords.Common.Gravity.FILL));
 //BA.debugLineNum = 184;BA.debugLine="glide.Load2(oMovie.Poster).Apply(glide.RO.Center";
mostCurrent._glide.Load2(mostCurrent.activityBA,_omovie.Poster).Apply(mostCurrent._glide.getRO().CenterCrop()).Into(_imgposter);
 //BA.debugLineNum = 185;BA.debugLine="pnlInfo.AddView( imgPoster, 0%x, 0, 25%x, 19%y)";
mostCurrent._pnlinfo.AddView((android.view.View)(_imgposter.getObject()),anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (0),mostCurrent.activityBA),(int) (0),anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (25),mostCurrent.activityBA),anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (19),mostCurrent.activityBA));
 //BA.debugLineNum = 188;BA.debugLine="Dim lblData(3)  As Label";
_lbldata = new anywheresoftware.b4a.objects.LabelWrapper[(int) (3)];
{
int d0 = _lbldata.length;
for (int i0 = 0;i0 < d0;i0++) {
_lbldata[i0] = new anywheresoftware.b4a.objects.LabelWrapper();
}
}
;
 //BA.debugLineNum = 189;BA.debugLine="For i = 0 To lblData.Length - 1";
{
final int step20 = 1;
final int limit20 = (int) (_lbldata.length-1);
_i = (int) (0) ;
for (;_i <= limit20 ;_i = _i + step20 ) {
 //BA.debugLineNum = 190;BA.debugLine="lblData(i).Initialize(\"\")";
_lbldata[_i].Initialize(mostCurrent.activityBA,"");
 //BA.debugLineNum = 191;BA.debugLine="lblData(i).TextColor = Colors.White";
_lbldata[_i].setTextColor(anywheresoftware.b4a.keywords.Common.Colors.White);
 //BA.debugLineNum = 192;BA.debugLine="lblData(i).Gravity = Bit.Or(Gravity.LEFT, Gravi";
_lbldata[_i].setGravity(anywheresoftware.b4a.keywords.Common.Bit.Or(anywheresoftware.b4a.keywords.Common.Gravity.LEFT,anywheresoftware.b4a.keywords.Common.Gravity.CENTER_VERTICAL));
 //BA.debugLineNum = 193;BA.debugLine="lblData(i).TextSize = 6%y*500/1000dip";
_lbldata[_i].setTextSize((float) (anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (6),mostCurrent.activityBA)*500/(double)anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1000))));
 //BA.debugLineNum = 194;BA.debugLine="lblData(i).Typeface = Typeface.SANS_SERIF";
_lbldata[_i].setTypeface(anywheresoftware.b4a.keywords.Common.Typeface.SANS_SERIF);
 //BA.debugLineNum = 195;BA.debugLine="lblData(i).Padding = Array As Int (10dip, 5dip,";
_lbldata[_i].setPadding(new int[]{anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5))});
 //BA.debugLineNum = 196;BA.debugLine="lblData(i).SingleLine = True";
_lbldata[_i].setSingleLine(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 198;BA.debugLine="pnlInfo.AddView( lblData(i), 25%x,0.5%y + 6.3%y";
mostCurrent._pnlinfo.AddView((android.view.View)(_lbldata[_i].getObject()),anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (25),mostCurrent.activityBA),(int) (anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (0.5),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (6.3),mostCurrent.activityBA)*_i),(int) (_width-anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (25),mostCurrent.activityBA)-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (15))),anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (6),mostCurrent.activityBA));
 }
};
 //BA.debugLineNum = 202;BA.debugLine="lblData(0).Text = oMovie.Title";
_lbldata[(int) (0)].setText(BA.ObjectToCharSequence(_omovie.Title));
 //BA.debugLineNum = 203;BA.debugLine="lblData(1).Text = oMovie.Year";
_lbldata[(int) (1)].setText(BA.ObjectToCharSequence(_omovie.Year));
 //BA.debugLineNum = 204;BA.debugLine="lblData(2).Text = oMovie.sType";
_lbldata[(int) (2)].setText(BA.ObjectToCharSequence(_omovie.sType));
 //BA.debugLineNum = 206;BA.debugLine="lblData(1).TextColor = Starter.colorSecondary";
_lbldata[(int) (1)].setTextColor(mostCurrent._starter._colorsecondary);
 //BA.debugLineNum = 207;BA.debugLine="lblData(2).TextSize = 6%y*320/1000dip";
_lbldata[(int) (2)].setTextSize((float) (anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (6),mostCurrent.activityBA)*320/(double)anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1000))));
 //BA.debugLineNum = 209;BA.debugLine="SetTextSize(lblData(0), lblData(0).Width - 15dip";
_settextsize(_lbldata[(int) (0)],(int) (_lbldata[(int) (0)].getWidth()-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (15))));
 //BA.debugLineNum = 212;BA.debugLine="Dim RateInt As Int = 0";
_rateint = (int) (0);
 //BA.debugLineNum = 213;BA.debugLine="Dim RateDec As Int = 0";
_ratedec = (int) (0);
 //BA.debugLineNum = 215;BA.debugLine="Try";
try { //BA.debugLineNum = 216;BA.debugLine="Dim fRate As Float = oMovie.imdbRating";
_frate = (float)(Double.parseDouble(_omovie.imdbRating));
 //BA.debugLineNum = 217;BA.debugLine="RateInt = fRate";
_rateint = (int) (_frate);
 //BA.debugLineNum = 218;BA.debugLine="RateDec = (fRate*10) - (RateInt*10)";
_ratedec = (int) ((_frate*10)-(_rateint*10));
 } 
       catch (Exception e43) {
			processBA.setLastException(e43); //BA.debugLineNum = 220;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("2852028",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA)),0);
 };
 //BA.debugLineNum = 225;BA.debugLine="For i = 1 To 10";
{
final int step45 = 1;
final int limit45 = (int) (10);
_i = (int) (1) ;
for (;_i <= limit45 ;_i = _i + step45 ) {
 //BA.debugLineNum = 227;BA.debugLine="Dim lblStar As Label";
_lblstar = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 228;BA.debugLine="lblStar.Initialize(\"\")";
_lblstar.Initialize(mostCurrent.activityBA,"");
 //BA.debugLineNum = 229;BA.debugLine="lblStar.TextColor = Starter.colorSecondary";
_lblstar.setTextColor(mostCurrent._starter._colorsecondary);
 //BA.debugLineNum = 230;BA.debugLine="lblStar.Typeface = Main.tFontawesome";
_lblstar.setTypeface((android.graphics.Typeface)(mostCurrent._main._tfontawesome.getObject()));
 //BA.debugLineNum = 232;BA.debugLine="lblStar.TextSize = 6%y*500/1000dip";
_lblstar.setTextSize((float) (anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (6),mostCurrent.activityBA)*500/(double)anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1000))));
 //BA.debugLineNum = 233;BA.debugLine="lblStar.Gravity = Bit.Or(Gravity.CENTER_HORIZON";
_lblstar.setGravity(anywheresoftware.b4a.keywords.Common.Bit.Or(anywheresoftware.b4a.keywords.Common.Gravity.CENTER_HORIZONTAL,anywheresoftware.b4a.keywords.Common.Gravity.CENTER_VERTICAL));
 //BA.debugLineNum = 235;BA.debugLine="If i < = RateInt Then";
if (_i<=_rateint) { 
 //BA.debugLineNum = 236;BA.debugLine="lblStar.Text = Chr(0xf005)";
_lblstar.setText(BA.ObjectToCharSequence(anywheresoftware.b4a.keywords.Common.Chr((int) (0xf005))));
 }else if(_i==(_rateint+1)) { 
 //BA.debugLineNum = 239;BA.debugLine="If RateDec<2 Then";
if (_ratedec<2) { 
 //BA.debugLineNum = 240;BA.debugLine="lblStar.Text = Chr(0xf006)";
_lblstar.setText(BA.ObjectToCharSequence(anywheresoftware.b4a.keywords.Common.Chr((int) (0xf006))));
 }else {
 //BA.debugLineNum = 242;BA.debugLine="lblStar.Text = Chr(0xf123)";
_lblstar.setText(BA.ObjectToCharSequence(anywheresoftware.b4a.keywords.Common.Chr((int) (0xf123))));
 };
 }else {
 //BA.debugLineNum = 246;BA.debugLine="lblStar.Text = Chr(0xf006)";
_lblstar.setText(BA.ObjectToCharSequence(anywheresoftware.b4a.keywords.Common.Chr((int) (0xf006))));
 };
 //BA.debugLineNum = 250;BA.debugLine="pnlHolder.AddView( lblStar ,10%x*(i-1), 20%y, 1";
mostCurrent._pnlholder.AddView((android.view.View)(_lblstar.getObject()),(int) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (10),mostCurrent.activityBA)*(_i-1)),anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (20),mostCurrent.activityBA),anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (10),mostCurrent.activityBA),anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (10),mostCurrent.activityBA));
 }
};
 //BA.debugLineNum = 257;BA.debugLine="Dim svDetail As ScrollView";
_svdetail = new anywheresoftware.b4a.objects.ScrollViewWrapper();
 //BA.debugLineNum = 258;BA.debugLine="svDetail.Initialize(0)";
_svdetail.Initialize(mostCurrent.activityBA,(int) (0));
 //BA.debugLineNum = 259;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 260;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 262;BA.debugLine="Dim lstData As List";
_lstdata = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 263;BA.debugLine="lstData.Initialize";
_lstdata.Initialize();
 //BA.debugLineNum = 264;BA.debugLine="lstData.AddAll(Array As String( oMovie.Plot , oM";
_lstdata.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_omovie.Plot,_omovie.Director,_omovie.Writer,_omovie.Language}));
 //BA.debugLineNum = 267;BA.debugLine="Dim lstTitle As List";
_lsttitle = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 268;BA.debugLine="lstTitle.Initialize";
_lsttitle.Initialize();
 //BA.debugLineNum = 269;BA.debugLine="lstTitle.AddAll(Array As String( \"Plot : \" , \"Di";
_lsttitle.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"Plot : ","Director : ","Writer : ","Language : "}));
 //BA.debugLineNum = 271;BA.debugLine="Dim intHeight As Int = 1%y";
_intheight = anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (1),mostCurrent.activityBA);
 //BA.debugLineNum = 273;BA.debugLine="Dim lblDetail(4)  As Label";
_lbldetail = new anywheresoftware.b4a.objects.LabelWrapper[(int) (4)];
{
int d0 = _lbldetail.length;
for (int i0 = 0;i0 < d0;i0++) {
_lbldetail[i0] = new anywheresoftware.b4a.objects.LabelWrapper();
}
}
;
 //BA.debugLineNum = 274;BA.debugLine="For i = 0 To lblDetail.Length - 1";
{
final int step77 = 1;
final int limit77 = (int) (_lbldetail.length-1);
_i = (int) (0) ;
for (;_i <= limit77 ;_i = _i + step77 ) {
 //BA.debugLineNum = 275;BA.debugLine="lblDetail(i).Initialize(\"\")";
_lbldetail[_i].Initialize(mostCurrent.activityBA,"");
 //BA.debugLineNum = 276;BA.debugLine="lblDetail(i).TextColor = Colors.White";
_lbldetail[_i].setTextColor(anywheresoftware.b4a.keywords.Common.Colors.White);
 //BA.debugLineNum = 277;BA.debugLine="lblDetail(i).Gravity = Bit.Or(Gravity.LEFT, Gra";
_lbldetail[_i].setGravity(anywheresoftware.b4a.keywords.Common.Bit.Or(anywheresoftware.b4a.keywords.Common.Gravity.LEFT,anywheresoftware.b4a.keywords.Common.Gravity.TOP));
 //BA.debugLineNum = 278;BA.debugLine="lblDetail(i).TextSize = 6%y*500/1000dip";
_lbldetail[_i].setTextSize((float) (anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (6),mostCurrent.activityBA)*500/(double)anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1000))));
 //BA.debugLineNum = 279;BA.debugLine="lblDetail(i).Typeface = Typeface.SANS_SERIF";
_lbldetail[_i].setTypeface(anywheresoftware.b4a.keywords.Common.Typeface.SANS_SERIF);
 //BA.debugLineNum = 280;BA.debugLine="lblDetail(i).Padding = Array As Int (5dip, 5dip";
_lbldetail[_i].setPadding(new int[]{anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5))});
 //BA.debugLineNum = 281;BA.debugLine="lblDetail(i).Text = cs.Initialize.Color(Colors.";
_lbldetail[_i].setText(BA.ObjectToCharSequence(_cs.Initialize().Color(anywheresoftware.b4a.keywords.Common.Colors.Gray).Append(BA.ObjectToCharSequence(_lsttitle.Get(_i))).Pop().Append(BA.ObjectToCharSequence(_lstdata.Get(_i))).PopAll().getObject()));
 //BA.debugLineNum = 283;BA.debugLine="svDetail.Panel.AddView( lblDetail(i) ,0%x, intH";
_svdetail.getPanel().AddView((android.view.View)(_lbldetail[_i].getObject()),anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (0),mostCurrent.activityBA),_intheight,_width,(int) (-2));
 //BA.debugLineNum = 284;BA.debugLine="intHeight = intHeight +  su.MeasureMultilineTex";
_intheight = (int) (_intheight+_su.MeasureMultilineTextHeight((android.widget.TextView)(_lbldetail[_i].getObject()),BA.ObjectToCharSequence(_lbldetail[_i].getText()))+anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (2),mostCurrent.activityBA));
 }
};
 //BA.debugLineNum = 288;BA.debugLine="svDetail.Panel.Height = intHeight";
_svdetail.getPanel().setHeight(_intheight);
 //BA.debugLineNum = 289;BA.debugLine="pnlInfo.AddView( svDetail ,0%x, 30%y, width, pnl";
mostCurrent._pnlinfo.AddView((android.view.View)(_svdetail.getObject()),anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (0),mostCurrent.activityBA),anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (30),mostCurrent.activityBA),_width,(int) (mostCurrent._pnlinfo.getHeight()-anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (30),mostCurrent.activityBA)));
 };
 //BA.debugLineNum = 299;BA.debugLine="End Sub";
return "";
}
public static String  _getmoviedetail(String _sid) throws Exception{
String _surl = "";
anywheresoftware.b4a.objects.collections.Map _updatelinks = null;
 //BA.debugLineNum = 59;BA.debugLine="Sub GetMovieDetail(sId As String)";
 //BA.debugLineNum = 62;BA.debugLine="If cPublic.CheckForInternet Then";
if (mostCurrent._cpublic._checkforinternet(mostCurrent.activityBA)) { 
 //BA.debugLineNum = 64;BA.debugLine="ProgressDialogShow2(\"لطفا چند لحظه صبر کنید\" , F";
anywheresoftware.b4a.keywords.Common.ProgressDialogShow2(mostCurrent.activityBA,BA.ObjectToCharSequence("لطفا چند لحظه صبر کنید"),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 65;BA.debugLine="Dim sURL As String = Starter.sBaseURL &  \"&i=\" &";
_surl = mostCurrent._starter._sbaseurl+"&i="+_sid;
 //BA.debugLineNum = 67;BA.debugLine="Try";
try { //BA.debugLineNum = 68;BA.debugLine="Dim UpdateLinks As Map";
_updatelinks = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 69;BA.debugLine="UpdateLinks.Initialize";
_updatelinks.Initialize();
 //BA.debugLineNum = 70;BA.debugLine="UpdateLinks.Put(\"getData\" , sURL)";
_updatelinks.Put((Object)("getData"),(Object)(_surl));
 //BA.debugLineNum = 72;BA.debugLine="serviceDataDownloader.TargetActivity = Me";
mostCurrent._servicedatadownloader._targetactivity = moviedetailactivity.getObject();
 //BA.debugLineNum = 73;BA.debugLine="serviceDataDownloader.CallbackFunction = \"DataR";
mostCurrent._servicedatadownloader._callbackfunction = "DataRecived_";
 //BA.debugLineNum = 74;BA.debugLine="CallSubDelayed2(serviceDataDownloader, \"Downloa";
anywheresoftware.b4a.keywords.Common.CallSubDelayed2(processBA,(Object)(mostCurrent._servicedatadownloader.getObject()),"Download",(Object)(_updatelinks));
 } 
       catch (Exception e12) {
			processBA.setLastException(e12); //BA.debugLineNum = 76;BA.debugLine="Log(LastException.Message)";
anywheresoftware.b4a.keywords.Common.LogImpl("2720913",anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA).getMessage(),0);
 };
 };
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return "";
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 13;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 16;BA.debugLine="Dim glide As Hitex_Glide";
mostCurrent._glide = new com.glide.Hitex_Glide();
 //BA.debugLineNum = 17;BA.debugLine="Private lblHeader As Label";
mostCurrent._lblheader = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private pnlHeader As Panel";
mostCurrent._pnlheader = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private pnlHolder As Panel";
mostCurrent._pnlholder = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private pnlInfo As Panel";
mostCurrent._pnlinfo = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private SelectedID As String = \"-1\"";
mostCurrent._selectedid = "-1";
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public static String  _loadoffline(String _sid) throws Exception{
b4a.example.cpublic._movie _omovie = null;
 //BA.debugLineNum = 436;BA.debugLine="Sub LoadOffline(sID As String )";
 //BA.debugLineNum = 438;BA.debugLine="Dim oMovie As Movie";
_omovie = new b4a.example.cpublic._movie();
 //BA.debugLineNum = 439;BA.debugLine="oMovie = cPublic.GetMovie(sID)";
_omovie = mostCurrent._cpublic._getmovie(mostCurrent.activityBA,_sid);
 //BA.debugLineNum = 441;BA.debugLine="FillMovieDetail(oMovie)";
_fillmoviedetail(_omovie);
 //BA.debugLineNum = 443;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public static String  _savetodb(b4a.example.cpublic._movie _omovie) throws Exception{
 //BA.debugLineNum = 426;BA.debugLine="Sub SaveToDb(oMovie As Movie)";
 //BA.debugLineNum = 428;BA.debugLine="If cPublic.IsMovieExists(oMovie.imdbID) Then";
if (mostCurrent._cpublic._ismovieexists(mostCurrent.activityBA,_omovie.imdbID)) { 
 //BA.debugLineNum = 429;BA.debugLine="cPublic.UpdateMovie(oMovie)";
mostCurrent._cpublic._updatemovie(mostCurrent.activityBA,_omovie);
 }else {
 //BA.debugLineNum = 431;BA.debugLine="cPublic.AddMovie(oMovie)";
mostCurrent._cpublic._addmovie(mostCurrent.activityBA,_omovie);
 };
 //BA.debugLineNum = 434;BA.debugLine="End Sub";
return "";
}
public static String  _settextsize(anywheresoftware.b4a.objects.LabelWrapper _lbl,int _lblwidth) throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnvs = null;
int _txtwidth = 0;
 //BA.debugLineNum = 405;BA.debugLine="Sub SetTextSize(lbl As Label, lblWidth As Int   )";
 //BA.debugLineNum = 408;BA.debugLine="Try";
try { //BA.debugLineNum = 409;BA.debugLine="Dim cnvs As Canvas";
_cnvs = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 410;BA.debugLine="cnvs.Initialize(Activity)";
_cnvs.Initialize((android.view.View)(mostCurrent._activity.getObject()));
 //BA.debugLineNum = 412;BA.debugLine="Dim txtWidth As Int = cnvs.MeasureStringWidth(lb";
_txtwidth = (int) (_cnvs.MeasureStringWidth(_lbl.getText(),_lbl.getTypeface(),_lbl.getTextSize()));
 //BA.debugLineNum = 414;BA.debugLine="If txtWidth > lblWidth Then";
if (_txtwidth>_lblwidth) { 
 //BA.debugLineNum = 415;BA.debugLine="Do While txtWidth > lblWidth";
while (_txtwidth>_lblwidth) {
 //BA.debugLineNum = 416;BA.debugLine="lbl.TextSize = lbl.TextSize- 0.2";
_lbl.setTextSize((float) (_lbl.getTextSize()-0.2));
 //BA.debugLineNum = 417;BA.debugLine="txtWidth = cnvs.MeasureStringWidth(lbl.Text ,";
_txtwidth = (int) (_cnvs.MeasureStringWidth(_lbl.getText(),_lbl.getTypeface(),_lbl.getTextSize()));
 }
;
 };
 } 
       catch (Exception e12) {
			processBA.setLastException(e12); //BA.debugLineNum = 421;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("2917520",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA)),0);
 };
 //BA.debugLineNum = 424;BA.debugLine="End Sub";
return "";
}
public static String  _showmoviedetails(String _sid) throws Exception{
 //BA.debugLineNum = 40;BA.debugLine="Sub ShowMovieDetails(sId As String)";
 //BA.debugLineNum = 42;BA.debugLine="SelectedID = sId";
mostCurrent._selectedid = _sid;
 //BA.debugLineNum = 44;BA.debugLine="If cPublic.CheckForInternet Then";
if (mostCurrent._cpublic._checkforinternet(mostCurrent.activityBA)) { 
 //BA.debugLineNum = 45;BA.debugLine="GetMovieDetail(sId)";
_getmoviedetail(_sid);
 }else {
 //BA.debugLineNum = 47;BA.debugLine="LoadOffline(sId)";
_loadoffline(_sid);
 };
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return "";
}
}
